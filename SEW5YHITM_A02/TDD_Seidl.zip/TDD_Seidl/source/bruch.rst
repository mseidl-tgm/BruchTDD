bruch module

-------------------
..automodule:: bruch
..autoclass:: BRUCH
    :members:
    :private-members:
    :undoc-members:
    :special-members:
    :show-inheritance: