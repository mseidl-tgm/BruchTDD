.. Seidl_TDD documentation master file, created by
   sphinx-quickstart on Wed Oct 26 17:06:26 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Seidl_TDD's documentation!
=====================================

Bibliographic fields:

---------------

      :Author: Maximilin Seidl
      :organization: TGM Wein
      :date: 2016-26-10
      :status: "ready for documentation"
      :version: 1.0


Contents:

---------------

.. toctree::
   :maxdepth: 2

   upoi

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

